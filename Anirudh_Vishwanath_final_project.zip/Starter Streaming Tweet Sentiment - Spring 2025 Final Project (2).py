# Databricks notebook source
# MAGIC %md
# MAGIC ## DSCC202-402 Data Science at Scale Final Project
# MAGIC ### Tracking Tweet sentiment at scale using a pretrained transformer (classifier)
# MAGIC <p>Consider the following illustration of the end to end system that you will be building.  Each student should do their own work.  The project will demonstrate your understanding of Spark Streaming, the medalion data architecture using Delta Lake, Spark Inference at Scale using an MLflow packaged model as well as Exploritory Data Analysis and System Tracking and Monitoring.</p>
# MAGIC <br><br>
# MAGIC <img src="https://data-science-at-scale.s3.amazonaws.com/images/pipeline.drawio.png">
# MAGIC
# MAGIC <p>
# MAGIC You will be pulling an updated copy of the course GitHub repositiory: <a href="https://github.com/lpalum/dscc202-402-spring2025">The Repo</a>.  
# MAGIC
# MAGIC Once you have updated your fork of the repository you should see the following template project that is resident in the final_project directory.
# MAGIC </p>
# MAGIC
# MAGIC <img src="https://data-science-at-scale.s3.amazonaws.com/images/notebooks.drawio.png">
# MAGIC
# MAGIC <p>
# MAGIC You can then pull your project into the Databrick Workspace using the <a href="https://github.com/apps/databricks">Databricks App on Github</a> or by cloning the repo to your laptop and then uploading the final_project directory and its contents to your workspace using file imports.  Your choice.
# MAGIC
# MAGIC <p>
# MAGIC Work your way through this notebook which will give you the steps required to submit a complete and compliant project.  The following illustration and associated data dictionary specifies the transformations and data that you are to generate for each step in the medallion pipeline.
# MAGIC </p>
# MAGIC <br><br>
# MAGIC <img src="https://data-science-at-scale.s3.amazonaws.com/images/dataframes.drawio.png">
# MAGIC
# MAGIC #### Bronze Data - raw ingest
# MAGIC - date - string in the source json
# MAGIC - user - string in the source json
# MAGIC - text - tweet string in the source json
# MAGIC - sentiment - the given sentiment of the text as determined by an unknown model that is provided in the source json
# MAGIC - source_file - the path of the source json file the this row of data was read from
# MAGIC - processing_time - a timestamp of when you read this row from the source json
# MAGIC
# MAGIC #### Silver Data - Bronze Preprocessing
# MAGIC - timestamp - convert date string in the bronze data to a timestamp
# MAGIC - mention - every @username mentioned in the text string in the bronze data gets a row in this silver data table.
# MAGIC - cleaned_text - the bronze text data with the mentions (@username) removed.
# MAGIC - sentiment - the given sentiment that was associated with the text in the bronze table.
# MAGIC
# MAGIC #### Gold Data - Silver Table Inference
# MAGIC - timestamp - the timestamp from the silver data table rows
# MAGIC - mention - the mention from the silver data table rows
# MAGIC - cleaned_text - the cleaned_text from the silver data table rows
# MAGIC - sentiment - the given sentiment from the silver data table rows
# MAGIC - predicted_score - score out of 100 from the Hugging Face Sentiment Transformer
# MAGIC - predicted_sentiment - string representation of the sentiment
# MAGIC - sentiment_id - 0 for negative and 1 for postive associated with the given sentiment
# MAGIC - predicted_sentiment_id - 0 for negative and 1 for positive assocaited with the Hugging Face Sentiment Transformer
# MAGIC
# MAGIC #### Application Data - Gold Table Aggregation
# MAGIC - min_timestamp - the oldest timestamp on a given mention (@username)
# MAGIC - max_timestamp - the newest timestamp on a given mention (@username)
# MAGIC - mention - the user (@username) that this row pertains to.
# MAGIC - negative - total negative tweets directed at this mention (@username)
# MAGIC - neutral - total neutral tweets directed at this mention (@username)
# MAGIC - positive - total positive tweets directed at this mention (@username)
# MAGIC
# MAGIC When you are designing your approach, one of the main decisions that you will need to make is how you are going to orchestrate the streaming data processing in your pipeline.  There are several valid approaches to triggering your steams and how you will gate the execution of your pipeline.  Think through how you want to proceed and ask questions if you need guidance. The following references may be helpful:
# MAGIC - [Spark Structured Streaming Programming Guide](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html)
# MAGIC - [Databricks Autoloader - Cloudfiles](https://docs.databricks.com/en/ingestion/auto-loader/index.html)
# MAGIC - [In class examples - Spark Structured Streaming Performance](https://dbc-f85bdc5b-07db.cloud.databricks.com/editor/notebooks/2638424645880316?o=1093580174577663)
# MAGIC
# MAGIC ### Be sure your project runs end to end when *Run all* is executued on this notebook! (7 points)
# MAGIC
# MAGIC ### This project is worth 25% of your final grade.
# MAGIC - DSCC-202 Students have 55 possible points on this project (see points above and the instructions below)
# MAGIC - DSCC-402 Students have 60 possible points on this project (one extra section to complete)

# COMMAND ----------

# DBTITLE 1,Pull in the Includes & Utiltites
# MAGIC %run ../Final_Project/includes

# COMMAND ----------

# DBTITLE 1,Notebook Control Widgets (maybe helpful)
"""
Adding a widget to the notebook to control the clearing of a previous run.
or stopping the active streams using routines defined in the utilities notebook
"""
dbutils.widgets.removeAll()

dbutils.widgets.dropdown("clear_previous_run", "No", ["No","Yes"])
if (getArgument("clear_previous_run") == "Yes"):
    clear_previous_run()
    print("Cleared all previous data.")

dbutils.widgets.dropdown("stop_streams", "No", ["No","Yes"])
if (getArgument("stop_streams") == "Yes"):
    stop_all_streams()
    print("Stopped all active streams.")

dbutils.widgets.dropdown("optimize_tables", "No", ["No","Yes"])
if (getArgument("optimize_tables") == "Yes"):
    # Suck up those small files that we have been appending.
    # Optimize the tables
    optimize_table(BRONZE_DELTA)
    optimize_table(SILVER_DELTA)
    optimize_table(GOLD_DELTA)
    print("Optimized all of the Delta Tables")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.0 Import your libraries here (2 points)
# MAGIC - Are your shuffle partitions consistent with your cluster and your workload?
# MAGIC - Do you have the necessary libraries to perform the required operations in the pipeline/application?

# COMMAND ----------

import sys
import time
import pyspark
import mlflow
import transformers
import emoji

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, explode, from_json
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline

BATCH_SIZE = 128 

# ─── Spark Session Setup ────────────────────────────────────────────────────

def create_spark_session(app_name="TweetSentimentStreaming"):
    """
    Creates and returns a Spark session with Delta Lake support.
    """
    return (
        SparkSession.builder
            .appName(app_name)
            .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
            .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
            .getOrCreate()
    )

def tune_shuffle_partitions(spark_session, multiplier=4):
    """
    Sets the number of shuffle partitions based on available cores.
    Returns the number of partitions set.
    """
    cores = spark_session.sparkContext.defaultParallelism
    partitions = cores * multiplier
    spark_session.conf.set("spark.sql.shuffle.partitions", str(partitions))
    return partitions

def collect_config_info(spark_session, partitions, batch_size):
    """
    Collects Spark configs and library versions into a dictionary.
    """
    return {
        "spark.sql.catalog.spark_catalog": spark_session.conf.get("spark.sql.catalog.spark_catalog"),
        "shuffle.partitions":               partitions,
        "pyspark version":                  pyspark.__version__,
        "mlflow version":                   mlflow.__version__,
        "transformers version":             transformers.__version__,
        "emoji version":                    emoji.__version__,
        "Spark version":                    spark_session.version,
        "Python version":                   sys.version.split()[0],
        "Batch size":                       batch_size
    }

def print_config_info(info_dict):
    """
    Neatly prints configuration and version information.
    """
    print("\nConfiguration & Library Versions:")
    for key, value in info_dict.items():
        print(f"  {key}: {value}")

# ─── Execution ──────────────────────────────────────────────────────────────

spark = create_spark_session()
partitions = tune_shuffle_partitions(spark)
config_info = collect_config_info(spark, partitions, BATCH_SIZE)
print_config_info(config_info)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 2.0 Define and execute utility functions (3 points)
# MAGIC - Read the source file directory listing
# MAGIC - Count the source files (how many are there?)
# MAGIC - print the contents of one of the files

# COMMAND ----------

import os


def list_json_file_paths(path_pattern):
    """
    Uses Spark to get a list of all input file paths matching the pattern.
    """
    return spark.read.text(path_pattern).inputFiles()

def sort_paths_by_filename(paths):
    """
    Sorts the list of file paths by their filename (basename).
    """
    return sorted(paths, key=lambda p: os.path.basename(p))

def preview_file(path, n=5):
    """
    Reads a single JSON file and displays its schema and top N rows.
    """
    print(f"\nShowing contents of sample file: {path}")
    df = spark.read.json(path)
    df.printSchema()
    df.show(n, truncate=False)
    return df

def print_file_summary(paths, display_limit=10):
    """
    Prints a summary of the number of files and names of the first few.
    """
    print(f"\nFound {len(paths)} raw tweet files in {TWEET_SOURCE_PATH}\n")
    print(f"First {display_limit} files:")
    for p in paths[:display_limit]:
        print(os.path.basename(p))

# Execution

# Step 1: List all tweet JSON files
raw_path = list_json_file_paths(f"{TWEET_SOURCE_PATH}/*.json")

# Step 2: Sort files by filename
sort_path = sort_paths_by_filename(raw_path)

# Step 3: Display file summary
print_file_summary(sort_path)

# Step 4: Preview the first file
sample_df = preview_file(sort_path[0])


# COMMAND ----------

# MAGIC %md
# MAGIC ## 3.0 Transform the Raw Data to Bronze Data using a stream  (8 points)
# MAGIC - define the schema for the raw data
# MAGIC - setup a read stream using cloudfiles and the source data format
# MAGIC - setup a write stream using delta lake to append to the bronze delta table
# MAGIC - enforce schema
# MAGIC - allow a new schema to be merged into the bronze delta table
# MAGIC - Use the defined BRONZE_CHECKPOINT and BRONZE_DELTA paths defined in the includes
# MAGIC - name your raw to bronze stream as bronze_stream
# MAGIC - transform the raw data to the bronze data using the data definition at the top of the notebook

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import (
    to_timestamp, regexp_replace, col,
    input_file_name, current_timestamp
)

# Schema Definition

def get_raw_tweet_schema():
    """
    Returns the enforced schema for raw tweet JSON records.
    """
    return StructType([
        StructField("date",      StringType()),
        StructField("sentiment", StringType()),
        StructField("text",      StringType()),
        StructField("user",      StringType()),
    ])

# Stream Reading Function

def read_raw_tweets_stream(path, checkpoint_path, schema):
    """
    Reads raw tweets as a streaming DataFrame using Auto Loader.
    Applies metadata enrichment and date parsing.
    """
    return (
        spark.readStream
             .format("cloudFiles")
             .option("cloudFiles.format", "json")
             .option("cloudFiles.schemaLocation", checkpoint_path)
             .option("cloudFiles.maxFilesPerTrigger", 500)
             .option("cloudFiles.useNotifications", "false")
             .schema(schema)
             .load(path)
             .withColumn("source_file", input_file_name())
             .withColumn("processing_time", current_timestamp())
             .withColumn(
                 "clean_date",
                 regexp_replace(
                     regexp_replace(col("date"), r"^\w{3}\s+", ""),
                     r"\s+[A-Z]{3}\s+", " "
                 )
             )
             .withColumn("event_time", to_timestamp(col("clean_date"), "MMM dd HH:mm:ss yyyy"))
             .drop("clean_date")
    )

#  Stream Writing Function

def write_bronze_stream(df, checkpoint_path, output_path, trigger_time="30 seconds"):
    """
    Writes the streaming DataFrame to the Bronze Delta table.
    Enables schema evolution and adds a trigger interval.
    """
    return (
        df.writeStream
          .trigger(processingTime=trigger_time)
          .format("delta")
          .option("checkpointLocation", checkpoint_path)
          .option("mergeSchema", "true")
          .queryName("bronze_stream")
          .outputMode("append")
          .start(output_path)
    )

# Bronze Pipeline Execution

raw_schema = get_raw_tweet_schema()
bronze_df = read_raw_tweets_stream(TWEET_SOURCE_PATH, BRONZE_CHECKPOINT, raw_schema)
bronze_stream = write_bronze_stream(bronze_df, BRONZE_CHECKPOINT, BRONZE_DELTA)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.0 Transform the Bronze Data to Silver Data using a stream (5 points)
# MAGIC - setup a read stream on your bronze delta table
# MAGIC - setup a write stream to append to the silver delta table
# MAGIC - Use the defined SILVER_CHECKPOINT and SILVER_DELTA paths in the includes
# MAGIC - name your bronze to silver stream as silver_stream
# MAGIC - transform the bronze data to the silver data using the data definition at the top of the notebook

# COMMAND ----------

from pyspark.sql.functions import col, split, explode, regexp_replace, expr

# Transformation Function

def transform_bronze_to_silver(bronze_path):
    """
    Reads data from the Bronze Delta table and performs:
    1. Extraction of @mentions
    2. Removal of mentions from text
    3. Selection of relevant fields for Silver
    Returns the transformed DataFrame.
    """
    return (
        spark.readStream
             .format("delta")
             .load(bronze_path)
             .withColumn(
                 "mention",
                 explode(
                     expr("filter(split(text, '\\s+'), w -> w rlike '^@[A-Za-z0-9_]+$')")
                 )
             )
             .withColumn(
                 "cleaned_text",
                 regexp_replace(col("text"), r"@([A-Za-z0-9_]+)", "")
             )
             .select(
                 col("event_time").alias("timestamp"),
                 col("mention"),
                 col("cleaned_text"),
                 col("sentiment")
             )
    )

# Stream Writing Function

def write_silver_stream(df, checkpoint_path, output_path, query_name="silver_stream"):
    """
    Writes the transformed Silver DataFrame to a Delta table.
    """
    return (
        df.writeStream
          .queryName(query_name)
          .format("delta")
          .option("checkpointLocation", checkpoint_path)
          .option("mergeSchema", "true")
          .outputMode("append")
          .start(output_path)
    )

# Silver Pipeline Execution

silver_df = transform_bronze_to_silver(BRONZE_DELTA)
silver_stream = write_silver_stream(silver_df, SILVER_CHECKPOINT, SILVER_DELTA)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.0 Transform the Silver Data to Gold Data using a stream (7 points)
# MAGIC - setup a read stream on your silver delta table
# MAGIC - setup a write stream to append to the gold delta table
# MAGIC - Use the defined GOLD_CHECKPOINT and GOLD_DELTA paths defines in the includes
# MAGIC - name your silver to gold stream as gold_stream
# MAGIC - transform the silver data to the gold data using the data definition at the top of the notebook
# MAGIC - Load the pretrained transformer sentiment classifier from the MODEL_NAME at the production level from the MLflow registry
# MAGIC - Use a spark UDF to parallelize the inference across your silver data

# COMMAND ----------

import mlflow
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql.functions import col, when


# Load MLflow Model as UDF

def load_sentiment_udf(model_name):
    """
    Loads the production version of a model from MLflow as a Spark UDF.
    """
    return mlflow.pyfunc.spark_udf(
        spark,
        f"models:/{model_name}/Production",
        result_type=StringType()
    )

# Gold Transformation Function

def transform_silver_to_gold(silver_path, sentiment_udf):
    """
    Applies the sentiment model to Silver data and derives Gold-level schema:
    Includes predicted sentiment, sentiment IDs, and final selected columns.
    """
    return (
        spark.readStream
             .format("delta")
             .load(silver_path)
             .withColumn("predicted_sentiment", sentiment_udf(col("cleaned_text")))
             .withColumn(
                 "sentiment_id",
                 when(col("sentiment") == "positive", 1).otherwise(0).cast(IntegerType())
             )
             .withColumn(
                 "predicted_sentiment_id",
                 when(col("predicted_sentiment") == "positive", 1).otherwise(0).cast(IntegerType())
             )
             .select(
                 col("timestamp"),
                 col("mention"),
                 col("cleaned_text"),
                 col("sentiment"),
                 col("predicted_sentiment"),
                 col("sentiment_id"),
                 col("predicted_sentiment_id")
             )
    )

# Stream Writing Function

def write_gold_stream(df, checkpoint_path, output_path, query_name="gold_stream"):
    """
    Writes the Gold-level stream to a Delta table.
    """
    return (
        df.writeStream
          .queryName(query_name)
          .format("delta")
          .option("checkpointLocation", checkpoint_path)
          .outputMode("append")
          .start(output_path)
    )

# Gold Pipeline Execution

sentiment_udf = load_sentiment_udf(MODEL_NAME)
gold_df = transform_silver_to_gold(SILVER_DELTA, sentiment_udf)
gold_stream = write_gold_stream(gold_df, GOLD_CHECKPOINT, GOLD_DELTA)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 6.0 Monitor your Streams (5 points)
# MAGIC - Setup a loop that runs at least every 10 seconds
# MAGIC - Print a timestamp of the monitoring query along with the list of streams, rows processed on each, and the processing time on each
# MAGIC - Run the loop until all of the data is processed (0 rows read on each active stream)
# MAGIC - Plot a line graph that shows the data processed by each stream over time
# MAGIC - Plot a line graph that shows the average processing time on each stream over time

# COMMAND ----------

import time
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

# Monitoring Functions

def poll_streams(sleep_seconds=10):
    """
    Polls active Spark structured streaming queries every `sleep_seconds` until
    all become idle (i.e., report zero new rows).
    
    Returns:
        List of dictionaries containing timestamped metrics for each stream.
    """
    metrics = []
    
    while True:
        timestamp = datetime.now()
        active_queries = spark.streams.active
        
        if not active_queries:
            print(f"{timestamp} - No active streams.")
            break

        all_zero = True

        for q in active_queries:
            prog = q.recentProgress[-1] if q.recentProgress else {}
            rows = prog.get("numInputRows", 0)
            duration = prog.get("batchDuration", 0)

            metrics.append({
                "timestamp": timestamp,
                "stream_id": q.id,
                "stream_name": q.name or q.id,
                "numInputRows": rows,
                "batchDuration": duration
            })

            print(f"{timestamp} | Stream {q.name or q.id}: rows={rows}, duration={duration} ms")
            if rows > 0:
                all_zero = False

        if all_zero:
            print(f"{timestamp} - All streams idle (0 rows). Exiting monitoring loop.")
            break

        time.sleep(sleep_seconds)
    
    return metrics

# Plotting Functions

def plot_stream_metric(df, metric_col, ylabel, title):
    """
    Plots the given metric column (e.g., numInputRows or batchDuration) over time.
    """
    ax = df.pivot(columns="stream_name", values=metric_col).plot(
        figsize=(10, 5), marker="o"
    )
    ax.set_xlabel("Time")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    plt.tight_layout()
    plt.show()

#  Execution

# Step 1: Poll the streams until idle
metrics = poll_streams()

# Step 2: Convert to DataFrame and plot if available
df_metrics = pd.DataFrame(metrics)

if df_metrics.empty:
    print("No metrics captured; skipping plots.")
else:
    df_metrics["timestamp"] = pd.to_datetime(df_metrics["timestamp"])
    df_metrics.set_index("timestamp", inplace=True)

    # Plot: Rows processed over time
    plot_stream_metric(df_metrics, "numInputRows", "Rows Processed", "Stream Input Rows Over Time")

    # Plot: Batch duration over time
    plot_stream_metric(df_metrics, "batchDuration", "Batch Duration (ms)", "Stream Batch Duration Over Time")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 7.0 Bronze Data Exploratory Data Analysis (5 points)
# MAGIC - How many tweets are captured in your Bronze Table?
# MAGIC - Are there any columns that contain Nan or Null values?  If so how many and what will you do in your silver transforms to address this?
# MAGIC - Count the number of tweets by each unique user handle and sort the data by descending count.
# MAGIC - How many tweets have at least one mention (@) how many tweet have no mentions (@)
# MAGIC - Plot a bar chart that shows the top 20 tweeters (users)
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col, sum as spark_sum, when
import matplotlib.pyplot as plt

# Load Function

def load_bronze_table(path):
    """
    Loads the Bronze Delta table from the given path.
    """
    return spark.read.format("delta").load(path)

# Analysis Functions

def count_total_tweets(df):
    """
    Returns and prints the total number of tweets.
    """
    total = df.count()
    print(f"Total tweets in Bronze: {total}")
    return total

def check_nulls_per_column(df):
    """
    Computes and displays the number of nulls per column.
    """
    null_df = (
        df.select([
            spark_sum(when(col(c).isNull(), 1).otherwise(0)).alias(c)
            for c in df.columns
        ])
        .toPandas()
        .T
        .rename(columns={0: "null_count"})
    )
    print("\nNulls per column:")
    display(null_df)
    return null_df

def compute_user_tweet_counts(df):
    """
    Returns tweet counts per user, sorted in descending order.
    """
    return df.groupBy("user").count().orderBy(col("count").desc())

def count_mentions(df, total_tweets):
    """
    Returns and prints counts of tweets with and without @mentions.
    """
    with_mentions = df.filter(col("text").rlike(r"@\w+")).count()
    without_mentions = total_tweets - with_mentions
    print(f"\nTweets with @mentions: {with_mentions}")
    print(f"Tweets without mentions: {without_mentions}")
    return with_mentions, without_mentions

# Execution
bronze_df = load_bronze_table(BRONZE_DELTA)

# Step 1: Total count
total_tweets = count_total_tweets(bronze_df)

# Step 2: Null value check
null_counts = check_nulls_per_column(bronze_df)

# Step 3: User tweet frequency
user_counts_df = compute_user_tweet_counts(bronze_df)
print("\nTweet counts by user (top 10):")
user_counts_df.show(10, truncate=False)

# Step 4: Mentions vs no-mentions
with_mentions, without_mentions = count_mentions(bronze_df, total_tweets)


# 7.5 Bar chart of top 20 tweeters
top20 = user_counts_df.limit(20).toPandas()

plt.figure(figsize=(12, 6))
plt.bar(top20['user'], top20['count'])
plt.xticks(rotation=45, ha='right')
plt.xlabel("User")
plt.ylabel("Tweet Count")
plt.title("Top 20 Tweeters")
plt.tight_layout()
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ## 8.0 Capture the accuracy metrics from the gold table in MLflow  (4 points)
# MAGIC Store the following in an MLflow experiment run:
# MAGIC - Store the precision, recall, and F1-score as MLflow metrics
# MAGIC - Store an image of the confusion matrix as an MLflow artifact
# MAGIC - Store the model name and the MLflow version that was used as an MLflow parameters
# MAGIC - Store the version of the Delta Table (input-silver) as an MLflow parameter

# COMMAND ----------

from pyspark.sql.functions import col, create_map, lit
from delta.tables import DeltaTable
from itertools import chain
import mlflow
import sklearn.metrics as skm
import matplotlib.pyplot as plt

# Constants

LABEL_MAP = {
    "LABEL_0": "negative", "LABEL_1": "neutral",  "LABEL_2": "positive",
    "NEG":     "negative", "NEU":     "neutral",  "POS":     "positive"
}
LABEL_ORDER = ["negative", "positive"]

# Functions

def load_gold_table(path):
    """
    Loads the Gold Delta table into a Spark DataFrame.
    """
    return spark.read.format("delta").load(path)

def map_sentiment_labels(df, label_map):
    """
    Maps raw sentiment prediction codes to human-readable labels.
    """
    mapping_expr = create_map(*list(chain.from_iterable([(lit(k), lit(v)) for k, v in label_map.items()])))
    return df.withColumn("pred_label", mapping_expr[col("predicted_sentiment")])

def filter_binary_labels(df):
    """
    Filters the dataset to only include rows with binary sentiment labels (pos/neg).
    """
    return df.filter(
        (col("sentiment").isin(*LABEL_ORDER)) & 
        (col("pred_label").isin(*LABEL_ORDER))
    )

def compute_metrics(y_true, y_pred):
    """
    Computes precision, recall, and F1 score.
    """
    precision, recall, f1, _ = skm.precision_recall_fscore_support(
        y_true, y_pred, labels=LABEL_ORDER, average="macro", zero_division=0
    )
    return precision, recall, f1

def plot_confusion_matrix(y_true, y_pred, output_file="confusion_matrix.png"):
    """
    Generates and saves a 2x2 confusion matrix plot.
    """
    cm = skm.confusion_matrix(y_true, y_pred, labels=LABEL_ORDER)
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
    ax.set_xticklabels(["neg", "pos"]); ax.set_yticklabels(["neg", "pos"])
    for i in (0, 1):
        for j in (0, 1):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max()/2 else "black")
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    plt.tight_layout()
    plt.savefig(output_file)

def get_table_version(path):
    """
    Returns the latest version number of the Delta table.
    """
    return DeltaTable.forPath(spark, path).history(1).collect()[0]["version"]

def log_metrics_to_mlflow(precision, recall, f1, model_name, gold_version, plot_path):
    """
    Logs evaluation metrics and parameters to MLflow.
    """
    with mlflow.start_run(run_name="gold_stage_accuracy"):
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall",    recall)
        mlflow.log_metric("f1_score",  f1)
        mlflow.log_param("model_name", model_name)
        mlflow.log_param("mlflow_version", mlflow.__version__)
        mlflow.log_param("input_gold_version", gold_version)
        mlflow.log_artifact(plot_path)

# Execution

# Step 1: Load and transform data
gold_df = load_gold_table(GOLD_DELTA)
gold_mapped_df = map_sentiment_labels(gold_df, LABEL_MAP)
binary_df = filter_binary_labels(gold_mapped_df)

# Step 2: Collect to pandas and evaluate
pdf = binary_df.select("sentiment", "pred_label").toPandas()
y_true, y_pred = pdf["sentiment"], pdf["pred_label"]
precision, recall, f1 = compute_metrics(y_true, y_pred)

# Step 3: Plot confusion matrix
plot_file = "confusion_matrix.png"
plot_confusion_matrix(y_true, y_pred, plot_file)

# Step 4: Log to MLflow
gold_version = get_table_version(GOLD_DELTA)
log_metrics_to_mlflow(precision, recall, f1, MODEL_NAME, gold_version, plot_file)

# Step 5: Confirmation
print(f"Logged metrics → precision={precision:.4f}, recall={recall:.4f}, f1={f1:.4f}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 9.0 Application Data Processing and Visualization (6 points)
# MAGIC - How many mentions are there in the gold data total?
# MAGIC - Count the number of neutral, positive and negative tweets for each mention in new columns
# MAGIC - Capture the total for each mention in a new column
# MAGIC - Sort the mention count totals in descending order
# MAGIC - Plot a bar chart of the top 20 mentions with positive sentiment (the people who are in favor)
# MAGIC - Plot a bar chart of the top 20 mentions with negative sentiment (the people who are the vilians)
# MAGIC
# MAGIC *note: A mention is a specific twitter user that has been "mentioned" in a tweet with an @user reference.

# COMMAND ----------

import matplotlib.pyplot as plt
import pandas as pd
from pyspark.sql.functions import col, create_map, lit
from itertools import chain

gold_df = spark.read.format("delta").load(GOLD_DELTA)

# Normalize predicted_sentiment codes to human-readable labels
label_map = {
    "LABEL_0": "negative", "LABEL_1": "neutral",  "LABEL_2": "positive",
    "NEG":     "negative", "NEU":       "neutral", "POS":      "positive"
}
map_expr = create_map(*chain.from_iterable([(lit(k), lit(v)) for k, v in label_map.items()]))
gold_norm = gold_df.withColumn("pred_label", map_expr[col("predicted_sentiment")])


pdf = gold_norm.select("mention", "pred_label").toPandas()

pdf = pdf.dropna(subset=["mention"])

mention_counts = (
    pdf.groupby(["mention", "pred_label"])
    .size()
    .unstack(fill_value=0)
)

for sentiment in ["negative", "neutral", "positive"]:
    if sentiment not in mention_counts.columns:
        mention_counts[sentiment] = 0

# Add total mention counts and sort 
mention_counts["total"] = mention_counts[["negative", "neutral", "positive"]].sum(axis=1)
sorted_counts = mention_counts.sort_values("total", ascending=False)

# Total mentions
total_mentions = int(mention_counts["total"].sum())
print(f"Total mention occurrences: {total_mentions}")

if total_mentions > 0:
    # ── Top 20 mentions by positive sentiment ──
    top_positive = sorted_counts.nlargest(20, "positive").reset_index()
    print("Top 20 Mentions by Positive Sentiment:")
    display(top_positive[["mention", "positive", "neutral", "negative", "total"]])

    # ── Bar chart for top 20 positive mentions ──
    plt.figure(figsize=(12, 6))
    plt.bar(top_positive["mention"], top_positive["positive"])
    plt.xticks(rotation=45, ha="right")
    plt.xlabel("Mention")
    plt.ylabel("Positive Mention Count")
    plt.title("Top 20 Mentions by Positive Sentiment")
    plt.tight_layout()
    plt.show()

    # ── Top 20 mentions by negative sentiment ──
    top_negative = sorted_counts.nlargest(20, "negative").reset_index()
    print("Top 20 Mentions by Negative Sentiment:")
    display(top_negative[["mention", "positive", "neutral", "negative", "total"]])

    # ── Bar chart for top 20 negative mentions ──
    plt.figure(figsize=(12, 6))
    plt.bar(top_negative["mention"], top_negative["negative"])
    plt.xticks(rotation=45, ha="right")
    plt.xlabel("Mention")
    plt.ylabel("Negative Mention Count")
    plt.title("Top 20 Mentions by Negative Sentiment")
    plt.tight_layout()
    plt.show()
else:
    print("No mentions found; skipping top-mention analysis and plotting.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 10.0 Clean up and completion of your pipeline (3 points)
# MAGIC - using the utilities what streams are running? If any.
# MAGIC - Stop all active streams
# MAGIC - print out the elapsed time of your notebook. Note: In the includes there is a variable START_TIME that captures the starting time of the notebook.

# COMMAND ----------

import time
from delta.tables import DeltaTable

def list_active_streams():
    """
    Prints a summary of currently active streaming queries.
    """
    active_queries = spark.streams.active
    if not active_queries:
        print("No active streaming queries.")
    else:
        print("Currently running streams:")
        for q in active_queries:
            print(f"  • id = {q.id}, status = {q.status['message']}")
    return active_queries

def stop_all_streams(active_queries):
    """
    Stops all active Spark streaming queries.
    """
    for q in active_queries:
        q.stop()
    print("All streaming queries have been stopped.\n")

def optimize_and_vacuum(path: str, retain_hours: int = 168):
    """
    Optimizes and vacuums a Delta table if it exists at the given path.
    """
    try:
        DeltaTable.forPath(spark, path)
        print(f"Optimizing {path}…")
        spark.sql(f"OPTIMIZE delta.`{path}`")
        print(f"Vacuuming {path} (retain {retain_hours} hours)…")
        spark.sql(f"VACUUM delta.`{path}` RETAIN {retain_hours} HOURS")
        print()
    except Exception as e:
        print(f"Skipping {path}: {e}\n")

def finalize_pipeline(delta_paths, start_time):
    """
    Runs final cleanup: stops streams, optimizes and vacuums tables, and logs duration.
    """
    # Step 1: List and stop streams
    active_queries = list_active_streams()
    if active_queries:
        stop_all_streams(active_queries)

    # Step 2: Optimize and vacuum each Delta table
    for path in delta_paths:
        optimize_and_vacuum(path)

    # Step 3: Print elapsed time
    elapsed = time.time() - start_time
    print(f"Notebook elapsed time: {elapsed:.2f} seconds")

# ─── Execution ──────────────────────────────────────────────────────────────

finalize_pipeline(
    delta_paths=[BRONZE_DELTA, SILVER_DELTA, GOLD_DELTA],
    start_time=START_TIME
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 11.0 How Optimized is your Spark Application (Grad Students Only) (5 points)
# MAGIC Graduate students (registered for the DSCC-402 section of the course) are required to do this section.  This is a written analysis using the Spark UI (link to screen shots) that support your analysis of your pipelines execution and what is driving its performance.
# MAGIC Recall that Spark Optimization has 5 significant dimensions of considertation:
# MAGIC - Spill: write to executor disk due to lack of memory
# MAGIC - Skew: imbalance in partition size
# MAGIC - Shuffle: network io moving data between executors (wide transforms)
# MAGIC - Storage: inefficiency due to disk storage format (small files, location)
# MAGIC - Serialization: distribution of code segments across the cluster
# MAGIC
# MAGIC Comment on each of the dimentions of performance and how your impelementation is or is not being affected.  Use specific information in the Spark UI to support your description.  
# MAGIC
# MAGIC Note: you can take sreenshots of the Spark UI from your project runs in databricks and then link to those pictures by storing them as a publicly accessible file on your cloud drive (google, one drive, etc.)
# MAGIC
# MAGIC References:
# MAGIC - [Spark UI Reference Reference](https://spark.apache.org/docs/latest/web-ui.html#web-ui)
# MAGIC - [Spark UI Simulator](https://www.databricks.training/spark-ui-simulator/index.html)

# COMMAND ----------

# MAGIC %md
# MAGIC SPILL - Spill occurs when Spark lacks sufficient memory and offloads data to disk, typically during shuffles or aggregations. In this case, the absence of spill indicators in the UI implies efficient memory usage and well-sized partitions, preventing performance degradation from disk IO.
# MAGIC
# MAGIC SKEW - Skew refers to imbalances in partition sizes that can lead to straggling tasks and uneven workload distribution. In this implementation, the Spark UI shows no significant skew—partition sizes appear balanced, and task rescheduling is minimal, indicating effective data partitioning.
# MAGIC
# MAGIC SHUFFLE -  shuffle refers to the movement of data between executors, typically triggered by wide transformations such as groupBy, join, or distinct
# MAGIC we see that 2756 scan tasks were executed, with 109 rescheduled, and that the cache hit ratio was moderate (61%). These indicators suggest some shuffle activity is present, likely from operations that redistribute data across partitions.
# MAGIC
# MAGIC STORAGE - The storage dimension shows underutilization of disk and IO cache, with a moderate 61% cache hit ratio and most data (145.1 MiB) read from external sources instead of cache (34.0 MiB). While Delta tables are fully cached in memory, optimizing file sizes and leveraging caching more effectively could improve performance.
# MAGIC
# MAGIC SERIALIZATION - Serialization in Spark involves converting data and code into a format suitable for distribution across the cluster. In your implementation, there are no signs of serialization issues—cached RDDs are stored using a standard "Serialized 1x Replicated" strategy, and there are no errors or warnings related to serialization in the Spark UI. This indicates that your data structures and user-defined functions are efficiently serialized and broadcasted across the executors without causing performance bottlenecks.
# MAGIC